from app import app

app.run(port="9090")