#items = {
#    0:{"id":0, "name": "First item"},
#    2:{"id":2, "name": "third item"}
#}

items = [{"id":0, "name": "First item"}, {"id":2, "name": "third item"}]

def search() -> list:
    return items