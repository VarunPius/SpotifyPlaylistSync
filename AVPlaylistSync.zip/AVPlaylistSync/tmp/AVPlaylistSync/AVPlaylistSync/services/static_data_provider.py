class DataProvider(object):
    